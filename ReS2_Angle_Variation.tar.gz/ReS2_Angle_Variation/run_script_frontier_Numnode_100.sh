#!/ccs/home/phanim/frontier/bin/rc
#SBATCH -A nti115
#SBATCH -J res2_30d
#SBATCH -t 02:00:00
#SBATCH -p batch
#SBATCH -N 150
##SBATCH -o res230d.scf.err_Nodes_100
#SBATCH --gpus-per-node 8
#SBATCH --ntasks-per-gpu 1
#SBATCH --gpu-bind closest
#SBATCH --dependency=singleton

OMP_NUM_THREADS = 1
MPICH_VERSION_DISPLAY=1
MPICH_ENV_DISPLAY=1
MPICH_OFI_NIC_POLICY = NUMA 
MPICH_GPU_SUPPORT_ENABLED=1
MPICH_SMP_SINGLE_COPY_MODE=NONE

INST=/lustre/orion/nti115/scratch/phanim/srinibas/install_DFTFE/env2
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$INST/lib
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$INST/lib/lib64
LD_LIBRARY_PATH=$CRAY_LD_LIBRARY_PATH:$LD_LIBRARY_PATH

BASE = /lustre/orion/nti115/scratch/phanim/srinibas/install_DFTFE/src/dftfe/build/release/real
n=`{echo $SLURM_JOB_NUM_NODES '*' 8 | bc}

module list 
ldd $BASE/dftfe
#srun -n $n -c 7 --gpu-bind closest $BASE/dftfe res2_orig.prm>res2_30D_origNew.out
srun -n $n -c 7 --gpu-bind closest $BASE/dftfe res2_origRestart.prm>res2_30D_restart13_noprecon.out
#srun -n $n -c 7 --gpu-bind closest $BASE/dftfe res2_30D_resta_AutoGpublockFalse_rest.prm  > res2_30D_AutoGpublockFalse_geoOpt_NumNodes_100_vdwRestartNew1.out


